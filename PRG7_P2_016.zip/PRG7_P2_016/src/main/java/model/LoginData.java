package model;

public class LoginData {

    private String nama;
    private int angkaVerif;

    public LoginData() {
    }

    public String getNama() {
        return nama;
    }

    public void setNama(String nama) {
        this.nama = nama;
    }

    public int getAngkaVerif() {
        return angkaVerif;
    }

    public void setAngkaVerif(int angkaVerif) {
        this.angkaVerif = angkaVerif;
    }
}
